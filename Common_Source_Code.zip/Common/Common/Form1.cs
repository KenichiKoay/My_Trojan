﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Common
{
    public partial class Sense : Form
    {
        public Sense()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
        }

        private void Sense_Load(object sender, EventArgs e)
        {
            if (MessageBox.Show("This malware is not a joke, are you sure you want to continue?", "Question", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
            {
                this.Close();
                Application.Exit();
            }
            else
            {
                Payloads();
            }
        }

        public void Payloads()
        {
            this.Hide();
            var NewForm = new Payload();
            NewForm.ShowDialog();
            this.Close();
        }
    }
}
