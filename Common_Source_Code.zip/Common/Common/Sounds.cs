﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Media;
using System.IO;

namespace Common
{
    public partial class Sounds : Form
    {
        private SoundPlayer _soundplayer;

        string sound_file = @"C:\Windows\Media\Windows Ding.wav";

        public Sounds()
        {
            InitializeComponent();
            this.TransparencyKey = this.BackColor;
            TopMost = true;
            if (File.Exists(sound_file))
            {
                _soundplayer = new SoundPlayer(@"C:\Windows\Media\Windows Critical Stop.wav");
            }
        }

        private void Sounds_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
        }

        private void Sounds_Load(object sender, EventArgs e)
        {
            tick1.Start();
            timer_payload.Start();
        }

        private void tick1_Tick(object sender, EventArgs e)
        {
            tick1.Stop();
            _soundplayer.Play();
            tick1.Start();
        }

        private void timer_payload_Tick(object sender, EventArgs e)
        {
            timer_payload.Stop();
            var NewForm = new Last();
            NewForm.ShowDialog();
            timer_payload.Start();
        }
    }
}
